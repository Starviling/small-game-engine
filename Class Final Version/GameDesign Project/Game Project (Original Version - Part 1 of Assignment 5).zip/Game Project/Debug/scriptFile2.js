function scriptFunction()
{
	printString("Hello World!");

	return "Script Success 3";
}

function scriptFunction2(message)
{
	printString(message);

	return "Script Success 4";
}

