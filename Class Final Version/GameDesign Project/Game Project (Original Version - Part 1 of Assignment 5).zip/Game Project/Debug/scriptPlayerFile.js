function playerSpeedAdjust(player)
{
	player.adjustSpeed(2.0);

	return "Script Success 1";
}

