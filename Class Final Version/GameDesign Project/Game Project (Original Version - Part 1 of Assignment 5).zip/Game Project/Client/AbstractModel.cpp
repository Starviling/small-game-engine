#include "AbstractModel.h"

AbstractModel::AbstractModel()
{
}
